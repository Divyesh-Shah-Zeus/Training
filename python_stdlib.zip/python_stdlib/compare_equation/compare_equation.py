#!/path/to/python
from sympy import *
from latex2sympy2 import latex2sympy
import re
import json
import argparse

def compare(equation1,equation2):
    try:
        equation1 = move_single_variable_right(equation1.replace("\\ \\frac", "+\\frac").replace("\\ ", ""))
        equation2 = move_single_variable_right(equation2.replace("\\ \\frac", "+\\frac").replace("\\ ", ""))
       
        if not equation1 or not equation2:
            return json.dumps({'error': 'Equations are missing'}), 400
       
        # result = check_and_evaluate_for_geometry(equation1,equation2)
        #if result:
        #    return result
       
        if ',' in equation1 or ',' in equation2:
            equation1 = parse_latex_interval(equation1)
            equation2 = parse_latex_interval(equation2)
       
        parseEquation1 = latex2sympy(replace_i_with_I(equation1))
        parseEquation2 = latex2sympy(replace_i_with_I(equation2))
 
        if isinstance(parseEquation1, list):
            parseEquation1 = parseEquation1[0]
        if isinstance(parseEquation2, list):
            parseEquation2 = parseEquation2[0]
 
        trig_functions = [sin, cos, tan, cot, sec, csc]
        if isinstance(parseEquation1, Eq) and isinstance(parseEquation2, Eq):  # Checking if both are equations
            # print("equations")
            variable_names = list(parseEquation1.free_symbols)
            # Solve the equations
            solution_equation1 = solve(parseEquation1, variable_names[0])
            solution_equation2 = solve(parseEquation2, variable_names[0])
 
            # Comparison
            are_equal1 = bool(solution_equation1[0].expand() == solution_equation2[0].expand())
           
            return are_equal1
        elif (isinstance(parseEquation1, Matrix) or (isinstance(parseEquation1, MatMul))) and (isinstance(parseEquation2, Matrix) or (isinstance(parseEquation2, MatMul))):
            # print("Matrix")
            are_equal1 = parseEquation1.equals(parseEquation2)
            return are_equal1
        elif any(isinstance(parseEquation1, func) for func in trig_functions) or any(isinstance(parseEquation2, func) for func in trig_functions):
            # # print("Trigonometry")
            are_equal1 = trigsimp(parseEquation1) == trigsimp(parseEquation2)
            return are_equal1
        else:  # Assuming both are expressions
            # Simplify expressions for comparison
            if validate_ratio_format(equation1) and validate_ratio_format(equation2):
                return check_equal_ratios(equation1, equation2)
            # elif ("infty" in equation1) or ("infty" in parseEquation2):
            #     are_equal = simplify(parseEquation1) == simplify(parseEquation2)
            #     return json.dumps({
            #         'math-equal': are_equal
            #     })        
            else:
                # print("expression")
                are_equal_simplify = simplify(parseEquation2) - simplify(parseEquation1) == 0
                are_equal_expand = bool(parseEquation2.expand() == parseEquation1.expand())
                # are_equal_simp = simplify(parseEquation1) == simplify(parseEquation2)
                are_equal = are_equal_expand or are_equal_simplify
               
                return are_equal
    except Exception as e:
        return json.dumps({'error': str(e)}), 500
 
def replace_i_with_I(expr):
    return re.sub(r'(?:^|([+\-0-9\(\{]))i', r'\g<1>I', expr)
 
def move_single_variable_right(expression):
    # Define a regular expression pattern to match the desired pattern
    pattern = r"([a-zA-Z])=([^=]+)"
 
    # Find all matches of the pattern in the expression
    matches = re.findall(pattern, expression)
 
    # If matches are found, replace the occurrences
    if matches:
        for match in matches:
            replaced_expression = match[1] + "=" + match[0]
            # expression = expression.replace(match[0], replaced_expression, 1)
            expression = replaced_expression
 
    return expression
 
def check_and_evaluate_for_geometry(option_stem, attempted_stem):
    GEOMETRY_SHAPE_REGEX = r'^(\\parallelogram|\\triangle|\\square) ([A-Za-z]+)$'
    geometry_shape_regex = re.compile(GEOMETRY_SHAPE_REGEX)
    option_match = geometry_shape_regex.match(option_stem)
    attempt_match = geometry_shape_regex.match(attempted_stem)
    if option_match and attempt_match and option_match.group(1) == attempt_match.group(1):
        option_vertices = option_match.group(2)
        attempted_vertices = attempt_match.group(2)
        return check_answer_for_polygon(option_vertices, attempted_vertices)
    return False
 
def check_answer_for_polygon(option_stem, attempted_stem):
    if len(option_stem) != len(attempted_stem):
        return False
    valid_answers = option_stem + option_stem
    return attempted_stem in valid_answers or attempted_stem[::-1] in valid_answers
 
def parse_ratio_string(ratio_str):
    # Split the input string by colon and convert each part to an integer
    return [int(part) for part in ratio_str.split(':')]
 
def check_equal_ratios(equation1_str, equation2_str):
    # Parse the ratio strings into lists of integers
    equation1_ratios = parse_ratio_string(equation1_str)
    equation2_ratios = parse_ratio_string(equation2_str)
 
    # Check if both ratios have exactly three numbers
    if len(equation1_ratios) != 3 or len(equation2_ratios) != 3:
        return False
 
    # Calculate the sum of ratios for equation1
    equation1_sum = sum(equation1_ratios)
 
    # Calculate the sum of ratios for equation2
    equation2_sum = sum(equation2_ratios)
 
    # Calculate ratios for equation1
    equation1_ratios_normalized = [rat / equation1_sum for rat in equation1_ratios]
 
    # Calculate ratios for equation2
    equation2_ratios_normalized = [rat / equation2_sum for rat in equation2_ratios]
   
    # Check if the ratios are equal
    return equation1_ratios_normalized == equation2_ratios_normalized
 
def validate_ratio_format(ratio_str):
    # Check if the ratio string contains two colons
    return ratio_str.count(':') == 2
 
def parse_latex_interval(latex_interval):
    interval_str = latex_interval.replace('\\left(', '').replace('\\right)', '')
    return interval_str

def parse_arguments():
    parser = argparse.ArgumentParser(description="Compare two equations")
    parser.add_argument("equation1", type=str, help="First equation")
    parser.add_argument("equation2", type=str, help="Second equation")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_arguments()
    result = compare(args.equation1, args.equation2)
    print(result)